## Environment
1. Node v12.2.0

## Get started
1. Run `npm i` to install all dependencies
2. Run `npm start` to start the server