const config = require('../config/config');
const Sequelize = require('sequelize');

const sequelize = new Sequelize(config.database, config.user, config.password, {
    host: config.host,
    dialect: config.dialect
});

class Controllers {
    getAll() {
        return console.log("It`s get all");
    }
    create() {
        return console.log("It`s a create!");
    }
    edit(id) {
        return console.log(`We can edit date id = ${id}`);
    }
    delete(id){
        return console.log('Delete date');
    }
}

module.exports = new Controllers();