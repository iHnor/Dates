const config = {
    host: 'localhost',
    user: 'admin',
    password: 'secret',
    database: 'dates',
    dialect: 'postgres',
};

module.exports = config;