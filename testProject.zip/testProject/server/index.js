const express = require('express')
const app = express()
const port = 3000
const controller = require('./controller/controller')

app.get('/', (req, res) => {
    res.send(controller.getAll())
});
app.get('/create', (req, res) => {
    res.send(controller.create())
});
app.get('/edit/:id', (req, res) => {
    res.send(controller.edit(req.params.id))
});
app.get('/:id', (req, res) => {
    res.send(controller.delete(req.params.id))
});

app.listen(port, () => { console.log(`App listening at http://localhost:${port}`) })